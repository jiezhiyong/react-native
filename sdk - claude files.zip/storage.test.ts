/**
 * __tests__/handlers/storage.test.ts
 *
 * 覆盖：
 * - setItem / getItem / removeItem / clear
 * - multiGet / multiSet / multiRemove
 * - 命名空间隔离（bridge: 前缀）
 * - 配额限制（>1MB 抛 STORAGE_QUOTA_EXCEEDED）
 * - 参数校验（key 为空、key 过长）
 * - 值类型（对象、数组、字符串、数字、null）
 * - clear 只清除 bridge: 命名空间
 */

import { createStorageHandlers } from '../../handlers/storage';
import { BridgeErrorCode } from '../../lib/bridge-error';

// ── Mock AsyncStorage ────────────────────────────────────────

const store: Record<string, string> = {};

jest.mock('@react-native-async-storage/async-storage', () => ({
  setItem:     jest.fn(async (k: string, v: string) => { store[k] = v; }),
  getItem:     jest.fn(async (k: string) => store[k] ?? null),
  removeItem:  jest.fn(async (k: string) => { delete store[k]; }),
  getAllKeys:   jest.fn(async () => Object.keys(store)),
  multiRemove: jest.fn(async (keys: string[]) => { keys.forEach(k => delete store[k]); }),
  multiGet:    jest.fn(async (keys: string[]) => keys.map(k => [k, store[k] ?? null])),
  multiSet:    jest.fn(async (pairs: [string, string][]) => { pairs.forEach(([k, v]) => { store[k] = v; }); }),
}));

const handlers = createStorageHandlers();

beforeEach(() => {
  // 清空 mock 存储
  Object.keys(store).forEach(k => delete store[k]);
});

// ── setItem / getItem ─────────────────────────────────────────

describe('storage.setItem / getItem', () => {
  test('存储和读取字符串', async () => {
    await handlers.setItem({ key: 'greeting', value: 'hello' });
    const { value } = await handlers.getItem({ key: 'greeting' }) as any;
    expect(value).toBe('hello');
  });

  test('存储和读取对象', async () => {
    const obj = { name: 'Alice', age: 30 };
    await handlers.setItem({ key: 'user', value: obj });
    const { value } = await handlers.getItem({ key: 'user' }) as any;
    expect(value).toEqual(obj);
  });

  test('存储和读取数组', async () => {
    await handlers.setItem({ key: 'list', value: [1, 2, 3] });
    const { value } = await handlers.getItem({ key: 'list' }) as any;
    expect(value).toEqual([1, 2, 3]);
  });

  test('存储和读取 null', async () => {
    await handlers.setItem({ key: 'empty', value: null });
    const { value } = await handlers.getItem({ key: 'empty' }) as any;
    expect(value).toBeNull();
  });

  test('不存在的 key 返回 { value: null }', async () => {
    const { value } = await handlers.getItem({ key: 'no-such-key' }) as any;
    expect(value).toBeNull();
  });

  test('key 自动加 bridge: 前缀（命名空间隔离）', async () => {
    await handlers.setItem({ key: 'myKey', value: 'myVal' });
    expect(store['bridge:myKey']).toBe('"myVal"');
    expect(store['myKey']).toBeUndefined(); // 裸 key 不存在
  });
});

// ── removeItem ────────────────────────────────────────────────

describe('storage.removeItem', () => {
  test('删除存在的 key', async () => {
    await handlers.setItem({ key: 'toDelete', value: 'val' });
    await handlers.removeItem({ key: 'toDelete' });
    const { value } = await handlers.getItem({ key: 'toDelete' }) as any;
    expect(value).toBeNull();
  });

  test('删除不存在的 key 不报错', async () => {
    await expect(handlers.removeItem({ key: 'ghost' })).resolves.toEqual({ ok: true });
  });
});

// ── clear ─────────────────────────────────────────────────────

describe('storage.clear', () => {
  test('只清除 bridge: 命名空间', async () => {
    store['bridge:a'] = '"1"';
    store['bridge:b'] = '"2"';
    store['other:c']  = '"3"'; // 其他命名空间，不应被清除
    const { ok, count } = await handlers.clear(null) as any;
    expect(ok).toBe(true);
    expect(count).toBe(2);
    expect(store['other:c']).toBe('"3"'); // 保留
    expect(store['bridge:a']).toBeUndefined();
    expect(store['bridge:b']).toBeUndefined();
  });

  test('没有 bridge: key 时 count 为 0', async () => {
    const { count } = await handlers.clear(null) as any;
    expect(count).toBe(0);
  });
});

// ── 批量操作 ──────────────────────────────────────────────────

describe('storage.multiSet / multiGet', () => {
  test('批量写入后批量读取', async () => {
    await handlers.multiSet({ items: { a: 1, b: 'two', c: [3] } });
    const { items } = await handlers.multiGet({ keys: ['a', 'b', 'c'] }) as any;
    expect(items.a).toBe(1);
    expect(items.b).toBe('two');
    expect(items.c).toEqual([3]);
  });

  test('multiGet 不存在的 key 返回 null', async () => {
    const { items } = await handlers.multiGet({ keys: ['x', 'y'] }) as any;
    expect(items.x).toBeNull();
    expect(items.y).toBeNull();
  });
});

describe('storage.multiRemove', () => {
  test('批量删除', async () => {
    await handlers.multiSet({ items: { d: 1, e: 2, f: 3 } });
    await handlers.multiRemove({ keys: ['d', 'e'] });
    const { items } = await handlers.multiGet({ keys: ['d', 'e', 'f'] }) as any;
    expect(items.d).toBeNull();
    expect(items.e).toBeNull();
    expect(items.f).toBe(3); // f 不受影响
  });
});

// ── 参数校验 ──────────────────────────────────────────────────

describe('storage 参数校验', () => {
  test('key 为空字符串时抛 INVALID_PARAMS', async () => {
    await expect(handlers.setItem({ key: '', value: 'v' }))
      .rejects.toMatchObject({ code: BridgeErrorCode.INVALID_PARAMS });
  });

  test('key 超过 256 字符时抛 INVALID_PARAMS', async () => {
    const longKey = 'a'.repeat(257);
    await expect(handlers.setItem({ key: longKey, value: 'v' }))
      .rejects.toMatchObject({ code: BridgeErrorCode.INVALID_PARAMS });
  });

  test('value 超过 1MB 时抛 STORAGE_QUOTA_EXCEEDED', async () => {
    const bigValue = 'x'.repeat(1024 * 1024 + 1);
    await expect(handlers.setItem({ key: 'big', value: bigValue }))
      .rejects.toMatchObject({ code: BridgeErrorCode.STORAGE_QUOTA_EXCEEDED });
  });

  test('multiGet keys 不是数组时抛 INVALID_PARAMS', async () => {
    await expect(handlers.multiGet({ keys: 'not-array' as any }))
      .rejects.toMatchObject({ code: BridgeErrorCode.INVALID_PARAMS });
  });

  test('multiSet items 不是对象时抛 INVALID_PARAMS', async () => {
    await expect(handlers.multiSet({ items: 'not-object' as any }))
      .rejects.toMatchObject({ code: BridgeErrorCode.INVALID_PARAMS });
  });

  test('缺少 key 字段时抛 INVALID_PARAMS（assertShape）', async () => {
    await expect(handlers.setItem({ value: 'v' } as any))
      .rejects.toMatchObject({ code: BridgeErrorCode.INVALID_PARAMS });
  });
});
