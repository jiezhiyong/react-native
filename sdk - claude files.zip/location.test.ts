/**
 * __tests__/handlers/location.test.ts
 *
 * 覆盖：
 * - getLocation：权限拒绝、成功返回、超时、定位不可用
 * - getLocation：includeSpeed / includeAltitude 字段控制
 * - getLocation：精度级别映射
 * - checkLocationPermission：各种权限状态
 * - timer 清理（location 先到 / timeout 先到）
 */

import { createLocationHandlers } from '../../handlers/location';
import { BridgeErrorCode } from '../../lib/bridge-error';

// ── Mock expo-location ───────────────────────────────────────

const mockRequestPermission = jest.fn();
const mockGetPermission      = jest.fn();
const mockGetCurrentPosition = jest.fn();

jest.mock('expo-location', () => ({
  Accuracy: {
    Lowest: 1, Low: 2, Balanced: 3, High: 4, Highest: 5, BestForNavigation: 6,
  },
  requestForegroundPermissionsAsync: () => mockRequestPermission(),
  getForegroundPermissionsAsync:     () => mockGetPermission(),
  getCurrentPositionAsync:           (opts: any) => mockGetCurrentPosition(opts),
}));

const handlers = createLocationHandlers();

const mockLocation = {
  coords: {
    latitude:         37.7749,
    longitude:       -122.4194,
    accuracy:         10,
    altitude:         50,
    altitudeAccuracy: 5,
    speed:            1.5,
    heading:          90,
  },
  timestamp: 1700000000000,
};

beforeEach(() => {
  jest.clearAllMocks();
  mockRequestPermission.mockResolvedValue({ status: 'granted' });
  mockGetPermission.mockResolvedValue({ status: 'granted' });
  mockGetCurrentPosition.mockResolvedValue(mockLocation);
});

// ── getLocation ───────────────────────────────────────────────

describe('location.getLocation', () => {
  test('权限被拒时抛 LOCATION_DENIED', async () => {
    mockRequestPermission.mockResolvedValue({ status: 'denied' });
    await expect(handlers.getLocation({}))
      .rejects.toMatchObject({ code: BridgeErrorCode.LOCATION_DENIED });
  });

  test('成功时返回经纬度和精度', async () => {
    const result = await handlers.getLocation({}) as any;
    expect(result.latitude).toBe(37.7749);
    expect(result.longitude).toBe(-122.4194);
    expect(result.accuracy).toBe(10);
    expect(result.timestamp).toBe(1700000000000);
  });

  test('默认不返回 speed 和 altitude', async () => {
    const result = await handlers.getLocation({}) as any;
    expect(result.speed).toBeUndefined();
    expect(result.altitude).toBeUndefined();
  });

  test('includeSpeed=true 时返回 speed 和 heading', async () => {
    const result = await handlers.getLocation({ includeSpeed: true }) as any;
    expect(result.speed).toBe(1.5);
    expect(result.heading).toBe(90);
  });

  test('includeAltitude=true 时返回 altitude 和 altitudeAccuracy', async () => {
    const result = await handlers.getLocation({ includeAltitude: true }) as any;
    expect(result.altitude).toBe(50);
    expect(result.altitudeAccuracy).toBe(5);
  });

  test('定位超时时抛 LOCATION_TIMEOUT', async () => {
    jest.useFakeTimers();
    mockGetCurrentPosition.mockImplementation(
      () => new Promise(() => {}), // 永远不 resolve
    );
    const promise = handlers.getLocation({ timeout: 100 });
    jest.advanceTimersByTime(200);
    await expect(promise).rejects.toMatchObject({ code: BridgeErrorCode.LOCATION_TIMEOUT });
    jest.useRealTimers();
  });

  test('location 先到时 timer 被清理（不会产生后续 reject）', async () => {
    jest.useFakeTimers();
    // location 立即 resolve
    mockGetCurrentPosition.mockResolvedValue(mockLocation);
    const promise = handlers.getLocation({ timeout: 5000 });
    // 推进时间超过超时，不应产生 LOCATION_TIMEOUT
    await Promise.resolve(); // 让 async 任务执行
    const result = await promise as any;
    expect(result.latitude).toBe(37.7749);
    // 推进到超时时间也不报错
    jest.advanceTimersByTime(6000);
    jest.useRealTimers();
  });

  test('getCurrentPositionAsync 抛未知错误时包装为 LOCATION_UNAVAILABLE', async () => {
    mockGetCurrentPosition.mockRejectedValue(new Error('GPS hardware error'));
    await expect(handlers.getLocation({}))
      .rejects.toMatchObject({ code: BridgeErrorCode.LOCATION_UNAVAILABLE });
  });

  test('精度级别映射：accuracy=high 传入正确枚举值', async () => {
    await handlers.getLocation({ accuracy: 'high' });
    expect(mockGetCurrentPosition).toHaveBeenCalledWith(
      expect.objectContaining({ accuracy: 4 }), // High = 4
    );
  });

  test('精度级别映射：默认 balanced', async () => {
    await handlers.getLocation({});
    expect(mockGetCurrentPosition).toHaveBeenCalledWith(
      expect.objectContaining({ accuracy: 3 }), // Balanced = 3
    );
  });
});

// ── checkLocationPermission ───────────────────────────────────

describe('location.checkLocationPermission', () => {
  test('权限已授予时返回 granted', async () => {
    mockGetPermission.mockResolvedValue({ status: 'granted' });
    const result = await handlers.checkLocationPermission(null) as any;
    expect(result.status).toBe('granted');
  });

  test('权限被拒时返回 denied', async () => {
    mockGetPermission.mockResolvedValue({ status: 'denied' });
    const result = await handlers.checkLocationPermission(null) as any;
    expect(result.status).toBe('denied');
  });

  test('权限未确定时返回 undetermined', async () => {
    mockGetPermission.mockResolvedValue({ status: 'undetermined' });
    const result = await handlers.checkLocationPermission(null) as any;
    expect(result.status).toBe('undetermined');
  });

  test('不触发权限申请', async () => {
    await handlers.checkLocationPermission(null);
    expect(mockRequestPermission).not.toHaveBeenCalled();
  });
});
