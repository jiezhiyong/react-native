/**
 * __tests__/lib/bridge-core-v6.test.ts
 *
 * 覆盖：
 * - createInstanceState 初始值
 * - BridgeCore 构造、buildInjectScript 缓存
 * - handleMessage：路由、白名单、handler 缺失、成功/失败回复
 * - pushEvent：就绪前队列、就绪后直接推送、destroy 后丢弃
 * - callH5：超时、bridge destroyed
 * - handleH5Reply：成功/失败/未知 code
 * - destroy：清理 pending callbacks
 * - updateCurrentUrl + 白名单联动
 */

import { createRef } from 'react';
import { BridgeCore, createInstanceState, BridgeOptions } from '../../lib/bridge-core-v6';
import { BridgeErrorCode } from '../../lib/bridge-error';

// ── Mock react-native-webview ────────────────────────────────

const mockInjectJavaScript = jest.fn();
const mockWebView = { injectJavaScript: mockInjectJavaScript };

function makeWebViewRef() {
  const ref = createRef<any>();
  (ref as any).current = mockWebView;
  return ref;
}

function makeBridge(opts: BridgeOptions = {}) {
  const ref = makeWebViewRef();
  const bridge = new BridgeCore(ref, { debug: false, timeout: 500, ...opts });
  return { bridge, ref };
}

// 从 injectJavaScript 调用中提取回传给 H5 的 payload
function extractReplyPayload(): Record<string, unknown> | null {
  const calls = mockInjectJavaScript.mock.calls;
  if (!calls.length) return null;
  const script = calls[calls.length - 1][0] as string;
  const match = script.match(/var p=(\{.*?\});/s);
  if (!match) return null;
  try { return JSON.parse(match[1]); } catch { return null; }
}

beforeEach(() => {
  mockInjectJavaScript.mockClear();
});

// ── createInstanceState ───────────────────────────────────────

describe('createInstanceState', () => {
  test('初始值全部为空/默认', () => {
    const state = createInstanceState();
    expect(state.bridgeId).toBe('');
    expect(state.scanResolver).toBeNull();
    expect(state.scanRejector).toBeNull();
    expect(state.loginResolver).toBeNull();
    expect(state.loginRejector).toBeNull();
    expect(state.gravitySubscriptions.size).toBe(0);
    expect(state.previewState.visible).toBe(false);
    expect(state.previewListeners).toHaveLength(0);
  });
});

// ── buildInjectScript ─────────────────────────────────────────

describe('BridgeCore.buildInjectScript', () => {
  test('返回非空字符串', () => {
    const { bridge } = makeBridge();
    const script = bridge.buildInjectScript();
    expect(typeof script).toBe('string');
    expect(script.length).toBeGreaterThan(100);
  });

  test('多次调用返回同一缓存引用', () => {
    const { bridge } = makeBridge();
    const s1 = bridge.buildInjectScript();
    const s2 = bridge.buildInjectScript();
    expect(s1).toBe(s2); // 严格引用相等，说明缓存生效
  });

  test('debug=true 时脚本包含 DEBUG = true', () => {
    const { bridge } = makeBridge({ debug: true });
    expect(bridge.buildInjectScript()).toContain('"debug":true');
  });

  test('脚本包含 __RNBridge__ 定义', () => {
    const { bridge } = makeBridge();
    expect(bridge.buildInjectScript()).toContain('__RNBridge__');
  });

  test('配置了白名单时脚本包含白名单域名', () => {
    const { bridge } = makeBridge({
      allowlist: { domains: ['special-domain.com'], allowLocalhost: false },
    });
    expect(bridge.buildInjectScript()).toContain('special-domain.com');
  });

  test('未配置白名单时脚本不包含 __RNBridgeAllowlist__', () => {
    const { bridge } = makeBridge();
    expect(bridge.buildInjectScript()).not.toContain('__RNBridgeAllowlist__');
  });
});

// ── handleMessage ─────────────────────────────────────────────

describe('BridgeCore.handleMessage', () => {
  test('非 Bridge 消息（无 __bridge__ 标志）被忽略', () => {
    const { bridge } = makeBridge();
    bridge.handleMessage({ type: 'custom', data: 'hello' });
    expect(mockInjectJavaScript).not.toHaveBeenCalled();
  });

  test('__bridgeReady__ 消息触发 H5 就绪状态', () => {
    const { bridge } = makeBridge();
    // 先 pushEvent（此时未就绪，进入队列）
    bridge.pushEvent('testEvent', { value: 1 });
    expect(mockInjectJavaScript).not.toHaveBeenCalled();
    // 触发就绪
    bridge.handleMessage({ __bridge__: true, method: '__bridgeReady__', id: '__ready__', data: null });
    // 队列冲刷，事件被推送
    expect(mockInjectJavaScript).toHaveBeenCalledTimes(1);
    const script = mockInjectJavaScript.mock.calls[0][0];
    expect(script).toContain('testEvent');
  });

  test('handler 不存在时回传 METHOD_NOT_FOUND', () => {
    const { bridge } = makeBridge();
    bridge.handleMessage({ __bridge__: true, id: 'msg-1', method: 'nonexistent', data: null });
    const payload = extractReplyPayload();
    expect(payload?.ok).toBe(false);
    expect(payload?.code).toBe(BridgeErrorCode.METHOD_NOT_FOUND);
  });

  test('handler 成功执行时回传 ok=true + data', async () => {
    const { bridge } = makeBridge();
    bridge.registerHandler('greet', async (data) => ({ hello: data }));
    bridge.handleMessage({ __bridge__: true, id: 'msg-2', method: 'greet', data: 'world' });
    // handler 是 async，等待微任务
    await new Promise(r => setImmediate(r));
    const payload = extractReplyPayload();
    expect(payload?.ok).toBe(true);
    expect((payload?.data as any)?.hello).toBe('world');
  });

  test('handler 抛出 BridgeError 时回传对应 code', async () => {
    const { bridge } = makeBridge();
    bridge.registerHandler('fail', async () => {
      const { BridgeError, BridgeErrorCode } = await import('../../lib/bridge-error');
      throw new BridgeError(BridgeErrorCode.USER_CANCELED);
    });
    bridge.handleMessage({ __bridge__: true, id: 'msg-3', method: 'fail', data: null });
    await new Promise(r => setImmediate(r));
    const payload = extractReplyPayload();
    expect(payload?.ok).toBe(false);
    expect(payload?.code).toBe(BridgeErrorCode.USER_CANCELED);
  });

  test('handler 抛出普通 Error 时回传 UNKNOWN（非 debug 模式）', async () => {
    const { bridge } = makeBridge({ debug: false });
    bridge.registerHandler('crash', async () => {
      throw new Error('内部崩溃信息');
    });
    bridge.handleMessage({ __bridge__: true, id: 'msg-4', method: 'crash', data: null });
    await new Promise(r => setImmediate(r));
    const payload = extractReplyPayload();
    expect(payload?.ok).toBe(false);
    expect(payload?.code).toBe(BridgeErrorCode.UNKNOWN);
    expect(payload?.message).not.toContain('内部崩溃信息'); // 不暴露内部信息
  });

  test('bridge 已 destroy 后消息被忽略', async () => {
    const { bridge } = makeBridge();
    bridge.registerHandler('echo', async (d) => d);
    bridge.destroy();
    bridge.handleMessage({ __bridge__: true, id: 'msg-5', method: 'echo', data: null });
    await new Promise(r => setImmediate(r));
    expect(mockInjectJavaScript).not.toHaveBeenCalled();
  });
});

// ── 白名单 ────────────────────────────────────────────────────

describe('BridgeCore 白名单', () => {
  test('currentUrl 为空时放行（等待第一次导航）', () => {
    const { bridge } = makeBridge({
      allowlist: { domains: ['example.com'], allowLocalhost: false },
      initialUrl: '', // 空 URL
    });
    bridge.registerHandler('ping', async () => 'pong');
    bridge.handleMessage({ __bridge__: true, id: 'w-1', method: 'ping', data: null });
    // 不应该被拒绝（应调用 handler）
    // 注意：handler 是 async，此处只验证没有立即回传 DOMAIN_NOT_ALLOWED
    const callCount = mockInjectJavaScript.mock.calls.length;
    // 没有同步回传（handler 是 async）
    expect(callCount).toBe(0);
  });

  test('currentUrl 不在白名单时回传 DOMAIN_NOT_ALLOWED', () => {
    const { bridge } = makeBridge({
      allowlist: { domains: ['example.com'], allowLocalhost: false },
      initialUrl: 'https://evil.com/page',
    });
    bridge.registerHandler('ping', async () => 'pong');
    bridge.handleMessage({ __bridge__: true, id: 'w-2', method: 'ping', data: null });
    const payload = extractReplyPayload();
    expect(payload?.ok).toBe(false);
    expect(payload?.code).toBe(BridgeErrorCode.DOMAIN_NOT_ALLOWED);
  });

  test('updateCurrentUrl 更新后白名单生效', () => {
    const { bridge } = makeBridge({
      allowlist: { domains: ['example.com'], allowLocalhost: false },
      initialUrl: '',
    });
    bridge.updateCurrentUrl('https://evil.com');
    bridge.registerHandler('ping', async () => 'pong');
    bridge.handleMessage({ __bridge__: true, id: 'w-3', method: 'ping', data: null });
    const payload = extractReplyPayload();
    expect(payload?.code).toBe(BridgeErrorCode.DOMAIN_NOT_ALLOWED);
  });
});

// ── pushEvent ─────────────────────────────────────────────────

describe('BridgeCore.pushEvent', () => {
  test('就绪前的事件进入队列，不立即推送', () => {
    const { bridge } = makeBridge();
    bridge.pushEvent('evt', { v: 1 });
    bridge.pushEvent('evt', { v: 2 });
    expect(mockInjectJavaScript).not.toHaveBeenCalled();
  });

  test('就绪后队列冲刷，按序推送', () => {
    const { bridge } = makeBridge();
    bridge.pushEvent('evt', { v: 1 });
    bridge.pushEvent('evt', { v: 2 });
    bridge.handleMessage({ __bridge__: true, method: '__bridgeReady__', id: '__ready__', data: null });
    expect(mockInjectJavaScript).toHaveBeenCalledTimes(2);
  });

  test('就绪后直接推送，不入队', () => {
    const { bridge } = makeBridge();
    bridge.handleMessage({ __bridge__: true, method: '__bridgeReady__', id: '__ready__', data: null });
    bridge.pushEvent('evt', { v: 3 });
    expect(mockInjectJavaScript).toHaveBeenCalledTimes(1);
  });

  test('destroy 后 pushEvent 被丢弃', () => {
    const { bridge } = makeBridge();
    bridge.handleMessage({ __bridge__: true, method: '__bridgeReady__', id: '__ready__', data: null });
    mockInjectJavaScript.mockClear();
    bridge.destroy();
    bridge.pushEvent('evt', { v: 4 });
    expect(mockInjectJavaScript).not.toHaveBeenCalled();
  });
});

// ── callH5 ────────────────────────────────────────────────────

describe('BridgeCore.callH5', () => {
  test('bridge destroyed 时立即 reject BRIDGE_DESTROYED', async () => {
    const { bridge } = makeBridge();
    bridge.destroy();
    await expect(bridge.callH5('anyMethod')).rejects.toMatchObject({
      code: BridgeErrorCode.BRIDGE_DESTROYED,
    });
  });

  test('超时后 reject TIMEOUT', async () => {
    const { bridge } = makeBridge({ timeout: 50 });
    const promise = bridge.callH5('slowMethod');
    await expect(promise).rejects.toMatchObject({
      code: BridgeErrorCode.TIMEOUT,
    });
  }, 500);

  test('注入脚本被调用', () => {
    const { bridge } = makeBridge();
    bridge.callH5('someMethod', { key: 'value' });
    expect(mockInjectJavaScript).toHaveBeenCalledTimes(1);
    const script = mockInjectJavaScript.mock.calls[0][0];
    expect(script).toContain('someMethod');
  });
});

// ── handleH5Reply ─────────────────────────────────────────────

describe('BridgeCore.handleH5Reply', () => {
  test('ok=true 时 resolve 对应的 callH5 Promise', async () => {
    const { bridge } = makeBridge({ timeout: 2000 });
    const promise = bridge.callH5<{ result: string }>('testMethod');

    // 模拟 H5 回复
    const callScript = mockInjectJavaScript.mock.calls[0][0];
    const idMatch = callScript.match(/"id":"(rn_[^"]+)"/);
    const id = idMatch?.[1];
    expect(id).toBeTruthy();

    bridge.handleH5Reply({ __bridge__: true, __isReply__: true, id, ok: true, data: { result: 'success' } });
    const result = await promise;
    expect(result.result).toBe('success');
  });

  test('ok=false 时 reject 带 code', async () => {
    const { bridge } = makeBridge({ timeout: 2000 });
    const promise = bridge.callH5('testMethod');

    const callScript = mockInjectJavaScript.mock.calls[0][0];
    const idMatch = callScript.match(/"id":"(rn_[^"]+)"/);
    const id = idMatch?.[1];

    bridge.handleH5Reply({ id, ok: false, code: BridgeErrorCode.USER_CANCELED });
    await expect(promise).rejects.toMatchObject({ code: BridgeErrorCode.USER_CANCELED });
  });

  test('未知 code → fallback 为 UNKNOWN', async () => {
    const { bridge } = makeBridge({ timeout: 2000 });
    const promise = bridge.callH5('testMethod');

    const callScript = mockInjectJavaScript.mock.calls[0][0];
    const idMatch = callScript.match(/"id":"(rn_[^"]+)"/);
    const id = idMatch?.[1];

    bridge.handleH5Reply({ id, ok: false, code: '99999' }); // 非法 code
    await expect(promise).rejects.toMatchObject({ code: BridgeErrorCode.UNKNOWN });
  });

  test('id 不存在时静默忽略', () => {
    const { bridge } = makeBridge();
    expect(() => {
      bridge.handleH5Reply({ id: 'non-existent', ok: true, data: null });
    }).not.toThrow();
  });
});

// ── destroy ───────────────────────────────────────────────────

describe('BridgeCore.destroy', () => {
  test('destroy 后所有 pending callbacks 以 BRIDGE_DESTROYED 拒绝', async () => {
    const { bridge } = makeBridge({ timeout: 10000 });
    const p1 = bridge.callH5('m1');
    const p2 = bridge.callH5('m2');
    bridge.destroy();
    await expect(p1).rejects.toMatchObject({ code: BridgeErrorCode.BRIDGE_DESTROYED });
    await expect(p2).rejects.toMatchObject({ code: BridgeErrorCode.BRIDGE_DESTROYED });
  });

  test('destroy 清空事件队列', () => {
    const { bridge } = makeBridge();
    bridge.pushEvent('e1');
    bridge.pushEvent('e2');
    bridge.destroy();
    // 就绪后队列应为空（已被 destroy 清空）
    bridge.handleMessage({ __bridge__: true, method: '__bridgeReady__', id: '__ready__', data: null });
    expect(mockInjectJavaScript).not.toHaveBeenCalled();
  });

  test('destroy 幂等（重复调用不报错）', () => {
    const { bridge } = makeBridge();
    expect(() => {
      bridge.destroy();
      bridge.destroy();
    }).not.toThrow();
  });
});
