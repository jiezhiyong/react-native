/**
 * __tests__/handlers/photo.test.ts
 *
 * 覆盖：
 * - pickImage：相机/相册权限拒绝、用户取消、成功返回
 * - previewImage：参数校验、setPreviewState 联动、订阅通知
 * - closePreview：重置状态
 * - saveImageToAlbum：权限拒绝、远程 URL 下载、本地 URI 直接保存
 *                    成功/失败双路径临时文件清理
 * - subscribePreview：回调触发时机
 */

import { createPhotoHandlers, subscribePreview, getPreviewState } from '../../handlers/photo';
import { createInstanceState } from '../../lib/bridge-core-v6';
import { BridgeErrorCode } from '../../lib/bridge-error';

// ── Mock expo-image-picker ────────────────────────────────────

const mockCameraLaunch  = jest.fn();
const mockLibraryLaunch = jest.fn();
const mockCameraPermission  = jest.fn();
const mockLibraryPermission = jest.fn();

jest.mock('expo-image-picker', () => ({
  MediaTypeOptions: { Images: 'images' },
  requestCameraPermissionsAsync:         () => mockCameraPermission(),
  requestMediaLibraryPermissionsAsync:   () => mockLibraryPermission(),
  launchCameraAsync:                     (opts: any) => mockCameraLaunch(opts),
  launchImageLibraryAsync:               (opts: any) => mockLibraryLaunch(opts),
}));

// ── Mock expo-media-library ───────────────────────────────────

const mockAlbumPermission = jest.fn();
const mockCreateAsset     = jest.fn();

jest.mock('expo-media-library', () => ({
  requestPermissionsAsync: () => mockAlbumPermission(),
  createAssetAsync:        (uri: string) => mockCreateAsset(uri),
}));

// ── Mock expo-file-system ─────────────────────────────────────

const mockDownload = jest.fn();
const mockDelete   = jest.fn();

jest.mock('expo-file-system', () => ({
  cacheDirectory: 'file:///cache/',
  downloadAsync:  (url: string, dest: string) => mockDownload(url, dest),
  deleteAsync:    (uri: string, opts: any)    => mockDelete(uri, opts),
}));

// ── Helpers ───────────────────────────────────────────────────

function makeHandlers() {
  const state    = createInstanceState();
  const handlers = createPhotoHandlers(state);
  return { state, handlers };
}

const mockAsset = {
  uri: 'file:///photos/img.jpg', width: 1920, height: 1080,
  fileSize: 512000, fileName: 'img.jpg', mimeType: 'image/jpeg',
};

beforeEach(() => {
  jest.clearAllMocks();
  mockCameraPermission.mockResolvedValue({ status: 'granted' });
  mockLibraryPermission.mockResolvedValue({ status: 'granted' });
  mockAlbumPermission.mockResolvedValue({ status: 'granted' });
  mockCreateAsset.mockResolvedValue({ id: 'asset-001' });
  mockDownload.mockResolvedValue({ uri: 'file:///cache/bridge_save_xxx.jpg' });
  mockDelete.mockResolvedValue(undefined);
});

// ── pickImage ─────────────────────────────────────────────────

describe('photo.pickImage', () => {
  test('相机权限拒绝时抛 CAMERA_DENIED', async () => {
    mockCameraPermission.mockResolvedValue({ status: 'denied' });
    const { handlers } = makeHandlers();
    await expect(handlers.pickImage({ source: 'camera' }))
      .rejects.toMatchObject({ code: BridgeErrorCode.CAMERA_DENIED });
  });

  test('相册权限拒绝时抛 MEDIA_DENIED', async () => {
    mockLibraryPermission.mockResolvedValue({ status: 'denied' });
    const { handlers } = makeHandlers();
    await expect(handlers.pickImage({ source: 'library' }))
      .rejects.toMatchObject({ code: BridgeErrorCode.MEDIA_DENIED });
  });

  test('用户取消时抛 USER_CANCELED', async () => {
    mockLibraryLaunch.mockResolvedValue({ canceled: true });
    const { handlers } = makeHandlers();
    await expect(handlers.pickImage({}))
      .rejects.toMatchObject({ code: BridgeErrorCode.USER_CANCELED });
  });

  test('相机成功时返回 assets 数组', async () => {
    mockCameraLaunch.mockResolvedValue({ canceled: false, assets: [mockAsset] });
    const { handlers } = makeHandlers();
    const result = await handlers.pickImage({ source: 'camera' }) as any;
    expect(result.assets).toHaveLength(1);
    expect(result.assets[0].uri).toBe(mockAsset.uri);
    expect(result.assets[0].width).toBe(1920);
  });

  test('相册多选时正确传递 selectionLimit', async () => {
    mockLibraryLaunch.mockResolvedValue({ canceled: false, assets: [mockAsset] });
    const { handlers } = makeHandlers();
    await handlers.pickImage({ source: 'library', multiple: true, maxCount: 5 });
    expect(mockLibraryLaunch).toHaveBeenCalledWith(
      expect.objectContaining({ allowsMultipleSelection: true, selectionLimit: 5 }),
    );
  });

  test('source 默认为 library', async () => {
    mockLibraryLaunch.mockResolvedValue({ canceled: false, assets: [mockAsset] });
    const { handlers } = makeHandlers();
    await handlers.pickImage({});
    expect(mockLibraryLaunch).toHaveBeenCalled();
    expect(mockCameraLaunch).not.toHaveBeenCalled();
  });
});

// ── previewImage ──────────────────────────────────────────────

describe('photo.previewImage', () => {
  test('缺少 urls 字段时抛 INVALID_PARAMS', async () => {
    const { handlers } = makeHandlers();
    await expect(handlers.previewImage({ current: 0 } as any))
      .rejects.toMatchObject({ code: BridgeErrorCode.INVALID_PARAMS });
  });

  test('urls 为空数组时抛 INVALID_PARAMS', async () => {
    const { handlers } = makeHandlers();
    await expect(handlers.previewImage({ urls: [] }))
      .rejects.toMatchObject({ code: BridgeErrorCode.INVALID_PARAMS });
  });

  test('成功时 previewState.visible 变为 true', async () => {
    const { state, handlers } = makeHandlers();
    await handlers.previewImage({ urls: ['https://a.com/img.jpg'], current: 0 });
    expect(getPreviewState(state).visible).toBe(true);
    expect(getPreviewState(state).urls).toEqual(['https://a.com/img.jpg']);
    expect(getPreviewState(state).current).toBe(0);
  });

  test('current 超出范围时被修正到合法值', async () => {
    const { state, handlers } = makeHandlers();
    await handlers.previewImage({ urls: ['a', 'b', 'c'], current: 99 });
    expect(getPreviewState(state).current).toBe(2); // clamp 到 urls.length - 1
  });

  test('触发订阅者通知', async () => {
    const { state, handlers } = makeHandlers();
    const listener = jest.fn();
    subscribePreview(state, listener);
    await handlers.previewImage({ urls: ['https://a.com/img.jpg'] });
    expect(listener).toHaveBeenCalledWith(
      expect.objectContaining({ visible: true }),
    );
  });
});

// ── closePreview ──────────────────────────────────────────────

describe('photo.closePreview', () => {
  test('关闭后 previewState 重置', async () => {
    const { state, handlers } = makeHandlers();
    await handlers.previewImage({ urls: ['https://a.com/img.jpg'] });
    await handlers.closePreview(null);
    const ps = getPreviewState(state);
    expect(ps.visible).toBe(false);
    expect(ps.urls).toHaveLength(0);
    expect(ps.current).toBe(0);
  });

  test('关闭时触发订阅者通知', async () => {
    const { state, handlers } = makeHandlers();
    const listener = jest.fn();
    subscribePreview(state, listener);
    await handlers.closePreview(null);
    expect(listener).toHaveBeenCalledWith(
      expect.objectContaining({ visible: false }),
    );
  });
});

// ── subscribePreview ──────────────────────────────────────────

describe('subscribePreview', () => {
  test('清理函数移除订阅者', async () => {
    const { state, handlers } = makeHandlers();
    const listener = jest.fn();
    const cleanup = subscribePreview(state, listener);
    cleanup();
    await handlers.previewImage({ urls: ['https://a.com/img.jpg'] });
    expect(listener).not.toHaveBeenCalled();
  });

  test('多个订阅者同时通知', async () => {
    const { state, handlers } = makeHandlers();
    const l1 = jest.fn();
    const l2 = jest.fn();
    subscribePreview(state, l1);
    subscribePreview(state, l2);
    await handlers.previewImage({ urls: ['https://a.com/img.jpg'] });
    expect(l1).toHaveBeenCalledTimes(1);
    expect(l2).toHaveBeenCalledTimes(1);
  });
});

// ── saveImageToAlbum ──────────────────────────────────────────

describe('photo.saveImageToAlbum', () => {
  test('相册权限拒绝时抛 MEDIA_DENIED', async () => {
    mockAlbumPermission.mockResolvedValue({ status: 'denied' });
    const { handlers } = makeHandlers();
    await expect(handlers.saveImageToAlbum({ url: 'https://a.com/img.jpg' }))
      .rejects.toMatchObject({ code: BridgeErrorCode.MEDIA_DENIED });
  });

  test('本地 URI 直接保存，不触发下载', async () => {
    const { handlers } = makeHandlers();
    await handlers.saveImageToAlbum({ url: 'file:///local/img.jpg' });
    expect(mockDownload).not.toHaveBeenCalled();
    expect(mockCreateAsset).toHaveBeenCalledWith('file:///local/img.jpg');
  });

  test('远程 URL 下载后保存到相册', async () => {
    const { handlers } = makeHandlers();
    const result = await handlers.saveImageToAlbum({ url: 'https://a.com/img.jpg' }) as any;
    expect(mockDownload).toHaveBeenCalledWith(
      'https://a.com/img.jpg',
      expect.stringContaining('bridge_save_'),
    );
    expect(mockCreateAsset).toHaveBeenCalled();
    expect(result.ok).toBe(true);
    expect(result.assetId).toBe('asset-001');
  });

  test('成功后异步清理临时文件（try/finally）', async () => {
    const { handlers } = makeHandlers();
    await handlers.saveImageToAlbum({ url: 'https://a.com/img.jpg' });
    await new Promise(r => setImmediate(r)); // 等待微任务
    expect(mockDelete).toHaveBeenCalledWith(
      'file:///cache/bridge_save_xxx.jpg',
      expect.objectContaining({ idempotent: true }),
    );
  });

  test('下载失败时抛 DOWNLOAD_FAILED，不调用 createAsset', async () => {
    mockDownload.mockRejectedValue(new Error('network error'));
    const { handlers } = makeHandlers();
    await expect(handlers.saveImageToAlbum({ url: 'https://a.com/img.jpg' }))
      .rejects.toMatchObject({ code: BridgeErrorCode.DOWNLOAD_FAILED });
    expect(mockCreateAsset).not.toHaveBeenCalled();
  });

  test('createAsset 失败时抛 ALBUM_SAVE_FAILED，且清理临时文件', async () => {
    mockCreateAsset.mockRejectedValue(new Error('disk full'));
    const { handlers } = makeHandlers();
    await expect(handlers.saveImageToAlbum({ url: 'https://a.com/img.jpg' }))
      .rejects.toMatchObject({ code: BridgeErrorCode.ALBUM_SAVE_FAILED });
    await new Promise(r => setImmediate(r));
    expect(mockDelete).toHaveBeenCalled(); // 失败路径也清理
  });

  test('缺少 url 字段时抛 INVALID_PARAMS', async () => {
    const { handlers } = makeHandlers();
    await expect(handlers.saveImageToAlbum({} as any))
      .rejects.toMatchObject({ code: BridgeErrorCode.INVALID_PARAMS });
  });
});
