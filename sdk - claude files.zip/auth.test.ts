/**
 * __tests__/handlers/auth.test.ts
 *
 * 覆盖：
 * - tryLogin：已登录/未登录两种路径
 * - forceLogin：已登录直接返回、防重复调用
 * - forceLogin：resolveLogin 触发 resolve
 * - forceLogin：rejectLogin 触发 reject
 * - forceLogin：60s 超时自动 reject（jest.useFakeTimers）
 * - logout：正常退出、重复退出报 ALREADY_LOGGED_OUT
 * - resolveLogin / rejectLogin：冗余 null 验证
 */

import { createAuthHandlers, resolveLogin, rejectLogin, UserInfo } from '../../handlers/auth';
import { createInstanceState } from '../../lib/bridge-core-v6';
import { BridgeErrorCode } from '../../lib/bridge-error';

// ── Mock ──────────────────────────────────────────────────────

const mockSetUser = jest.fn();
const mockGetState = jest.fn();

jest.mock('@/lib/store', () => ({
  useAppStore: {
    getState: () => mockGetState(),
  },
}));

jest.mock('expo-router', () => ({
  router: { push: jest.fn() },
}));

const mockUser: UserInfo = {
  userId:   'u1',
  username: 'alice',
  nickname: 'Alice',
  avatar:   'https://example.com/avatar.jpg',
  token:    'tok-xxx',
};

function makeHandlers() {
  const state = createInstanceState();
  state.bridgeId = 'test-bridge-id';
  const handlers = createAuthHandlers(state);
  return { state, handlers };
}

beforeEach(() => {
  mockSetUser.mockReset();
  mockGetState.mockReturnValue({ user: null, setUser: mockSetUser });
  jest.clearAllMocks();
});

// ── tryLogin ──────────────────────────────────────────────────

describe('auth.tryLogin', () => {
  test('未登录时返回 { isLoggedIn: false }', async () => {
    mockGetState.mockReturnValue({ user: null, setUser: mockSetUser });
    const { handlers } = makeHandlers();
    const result = await handlers.tryLogin(null) as any;
    expect(result.isLoggedIn).toBe(false);
    expect(result.user).toBeUndefined();
  });

  test('已登录时返回用户信息（不含 token）', async () => {
    mockGetState.mockReturnValue({ user: mockUser, setUser: mockSetUser });
    const { handlers } = makeHandlers();
    const result = await handlers.tryLogin(null) as any;
    expect(result.isLoggedIn).toBe(true);
    expect(result.user.userId).toBe('u1');
    expect(result.user.username).toBe('alice');
    expect(result.user.token).toBeUndefined(); // token 不暴露给 H5
  });
});

// ── forceLogin ────────────────────────────────────────────────

describe('auth.forceLogin', () => {
  test('已登录时直接返回用户信息', async () => {
    mockGetState.mockReturnValue({ user: mockUser, setUser: mockSetUser });
    const { handlers } = makeHandlers();
    const result = await handlers.forceLogin(null) as any;
    expect(result.isLoggedIn).toBe(true);
    expect(result.user.nickname).toBe('Alice');
  });

  test('防重复调用：loginResolver 已存在时抛 UNKNOWN', async () => {
    mockGetState.mockReturnValue({ user: null, setUser: mockSetUser });
    const { state, handlers } = makeHandlers();
    // 模拟第一次调用挂起
    state.loginResolver = jest.fn();
    await expect(handlers.forceLogin(null))
      .rejects.toMatchObject({ code: BridgeErrorCode.UNKNOWN });
  });

  test('resolveLogin 触发 forceLogin Promise resolve', async () => {
    mockGetState.mockReturnValue({ user: null, setUser: mockSetUser });
    const { state, handlers } = makeHandlers();
    const promise = handlers.forceLogin({ source: 'test' }) as Promise<any>;

    // 模拟登录页完成登录
    resolveLogin(state, mockUser);

    const result = await promise;
    expect(result.isLoggedIn).toBe(true);
    expect(result.user.userId).toBe('u1');
    expect(mockSetUser).toHaveBeenCalledWith(mockUser);
  });

  test('resolveLogin 后 state 内的 resolver/rejector 被清空', async () => {
    mockGetState.mockReturnValue({ user: null, setUser: mockSetUser });
    const { state, handlers } = makeHandlers();
    handlers.forceLogin(null);
    resolveLogin(state, mockUser);
    await new Promise(r => setImmediate(r));
    expect(state.loginResolver).toBeNull();
    expect(state.loginRejector).toBeNull();
  });

  test('rejectLogin 触发 forceLogin Promise reject（USER_CANCELED）', async () => {
    mockGetState.mockReturnValue({ user: null, setUser: mockSetUser });
    const { state, handlers } = makeHandlers();
    const promise = handlers.forceLogin(null);
    rejectLogin(state); // 默认 USER_CANCELED
    await expect(promise).rejects.toMatchObject({ code: BridgeErrorCode.USER_CANCELED });
  });

  test('rejectLogin 后 state 内的 resolver/rejector 被清空', async () => {
    mockGetState.mockReturnValue({ user: null, setUser: mockSetUser });
    const { state, handlers } = makeHandlers();
    handlers.forceLogin(null);
    rejectLogin(state);
    await new Promise(r => setImmediate(r));
    expect(state.loginResolver).toBeNull();
    expect(state.loginRejector).toBeNull();
  });

  test('60s 超时后自动 reject LOGIN_FAILED', async () => {
    jest.useFakeTimers();
    mockGetState.mockReturnValue({ user: null, setUser: mockSetUser });
    const { handlers } = makeHandlers();
    const promise = handlers.forceLogin(null);
    jest.advanceTimersByTime(61_000);
    await expect(promise).rejects.toMatchObject({ code: BridgeErrorCode.LOGIN_FAILED });
    jest.useRealTimers();
  });

  test('settled=true 后重复触发 resolve 无效（幂等）', async () => {
    mockGetState.mockReturnValue({ user: null, setUser: mockSetUser });
    const { state, handlers } = makeHandlers();
    const promise = handlers.forceLogin(null);
    resolveLogin(state, mockUser);
    // 第二次触发（模拟误操作）
    resolveLogin(state, { ...mockUser, userId: 'u2' });
    const result = await promise;
    expect(result.user.userId).toBe('u1'); // 第一次触发的结果
    expect(mockSetUser).toHaveBeenCalledTimes(1); // setUser 只调用一次
  });
});

// ── logout ────────────────────────────────────────────────────

describe('auth.logout', () => {
  test('已登录时正常退出，返回 { ok: true }', async () => {
    mockGetState.mockReturnValue({ user: mockUser, setUser: mockSetUser });
    const { handlers } = makeHandlers();
    const result = await handlers.logout(null) as any;
    expect(result.ok).toBe(true);
    expect(mockSetUser).toHaveBeenCalledWith(null);
  });

  test('未登录时抛 ALREADY_LOGGED_OUT', async () => {
    mockGetState.mockReturnValue({ user: null, setUser: mockSetUser });
    const { handlers } = makeHandlers();
    await expect(handlers.logout(null))
      .rejects.toMatchObject({ code: BridgeErrorCode.ALREADY_LOGGED_OUT });
  });

  test('logout 时清理挂起的 forceLogin（触发 USER_CANCELED）', async () => {
    mockGetState
      .mockReturnValueOnce({ user: null, setUser: mockSetUser })   // forceLogin 检查
      .mockReturnValueOnce({ user: mockUser, setUser: mockSetUser }); // logout 检查
    const { state, handlers } = makeHandlers();
    const loginPromise = handlers.forceLogin(null);
    // 模拟 forceLogin 挂起后调用 logout
    await handlers.logout(null);
    await expect(loginPromise).rejects.toMatchObject({ code: BridgeErrorCode.USER_CANCELED });
  });
});
