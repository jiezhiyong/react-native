/**
 * __tests__/lib/bridge-allowlist.test.ts
 *
 * 覆盖：
 * - matchDomain：精确匹配、通配符匹配、边界情况
 * - isHostAllowed：localhost 特殊处理、白名单命中/未命中
 * - isUrlAllowed：协议校验、非法 URL 处理、完整组合场景
 * - buildAllowlistScript：输出包含关键字符串
 */

import {
  isHostAllowed,
  isUrlAllowed,
  buildAllowlistScript,
  AllowlistOptions,
} from '../../lib/bridge-allowlist';

const baseOptions: AllowlistOptions = {
  domains: ['example.com', '*.example.com'],
  allowLocalhost: false,
  allowHttp: false,
};

// ── matchDomain（通过 isHostAllowed 间接测试）────────────────

describe('matchDomain — 精确匹配', () => {
  test('精确匹配：完全相同的域名命中', () => {
    expect(isHostAllowed('example.com', { ...baseOptions, allowLocalhost: false })).toBe(true);
  });

  test('精确匹配：子域名不命中精确模式', () => {
    const opts: AllowlistOptions = { domains: ['example.com'], allowLocalhost: false };
    expect(isHostAllowed('sub.example.com', opts)).toBe(false);
  });

  test('精确匹配：大小写敏感（域名规范应为小写）', () => {
    expect(isHostAllowed('Example.com', baseOptions)).toBe(false);
  });
});

describe('matchDomain — 通配符匹配', () => {
  test('*.example.com 匹配 sub.example.com', () => {
    expect(isHostAllowed('sub.example.com', baseOptions)).toBe(true);
  });

  test('*.example.com 匹配 deep.sub.example.com', () => {
    expect(isHostAllowed('deep.sub.example.com', baseOptions)).toBe(true);
  });

  test('*.example.com 不匹配 example.com 本身', () => {
    const opts: AllowlistOptions = { domains: ['*.example.com'], allowLocalhost: false };
    expect(isHostAllowed('example.com', opts)).toBe(false);
  });

  test('*.example.com 不匹配 notexample.com（后缀相同但不是子域名）', () => {
    expect(isHostAllowed('notexample.com', baseOptions)).toBe(false);
  });

  test('通配符只匹配一级以上前缀（不接受空前缀）', () => {
    // 'example.com' 与 '*.example.com' 中 suffix = '.example.com'
    // 'example.com'.endsWith('.example.com') = false，正确不匹配
    const opts: AllowlistOptions = { domains: ['*.example.com'], allowLocalhost: false };
    expect(isHostAllowed('example.com', opts)).toBe(false);
  });
});

describe('isHostAllowed — localhost', () => {
  test('allowLocalhost=true：localhost 放行', () => {
    const opts: AllowlistOptions = { domains: [], allowLocalhost: true };
    expect(isHostAllowed('localhost', opts)).toBe(true);
  });

  test('allowLocalhost=true：127.0.0.1 放行', () => {
    const opts: AllowlistOptions = { domains: [], allowLocalhost: true };
    expect(isHostAllowed('127.0.0.1', opts)).toBe(true);
  });

  test('allowLocalhost=false（默认）：localhost 不放行', () => {
    const opts: AllowlistOptions = { domains: [], allowLocalhost: false };
    expect(isHostAllowed('localhost', opts)).toBe(false);
  });

  test('allowLocalhost 未传时默认为 true', () => {
    const opts: AllowlistOptions = { domains: [] };
    expect(isHostAllowed('localhost', opts)).toBe(true);
  });
});

describe('isUrlAllowed', () => {
  test('HTTPS + 命中域名 → 允许', () => {
    expect(isUrlAllowed('https://example.com/path', baseOptions)).toBe(true);
  });

  test('HTTPS + 通配符子域名 → 允许', () => {
    expect(isUrlAllowed('https://api.example.com/v1', baseOptions)).toBe(true);
  });

  test('HTTP + allowHttp=false → 拒绝', () => {
    expect(isUrlAllowed('http://example.com', baseOptions)).toBe(false);
  });

  test('HTTP + allowHttp=true → 允许', () => {
    const opts: AllowlistOptions = { ...baseOptions, allowHttp: true };
    expect(isUrlAllowed('http://example.com', opts)).toBe(true);
  });

  test('HTTP + localhost + allowHttp=false → 允许（localhost 例外）', () => {
    const opts: AllowlistOptions = { domains: [], allowLocalhost: true, allowHttp: false };
    expect(isUrlAllowed('http://localhost:3000', opts)).toBe(true);
  });

  test('非法 URL → 拒绝', () => {
    expect(isUrlAllowed('not-a-url', baseOptions)).toBe(false);
    expect(isUrlAllowed('', baseOptions)).toBe(false);
  });

  test('未命中白名单域名 → 拒绝', () => {
    expect(isUrlAllowed('https://evil.com', baseOptions)).toBe(false);
  });

  test('带端口的 URL 正常解析', () => {
    const opts: AllowlistOptions = { domains: ['example.com'], allowLocalhost: false };
    expect(isUrlAllowed('https://example.com:8443/path', opts)).toBe(true);
  });
});

describe('buildAllowlistScript', () => {
  test('输出包含白名单域名 JSON', () => {
    const script = buildAllowlistScript({ domains: ['example.com', '*.test.com'] });
    expect(script).toContain('"example.com"');
    expect(script).toContain('"*.test.com"');
  });

  test('输出包含 isAllowed 函数', () => {
    const script = buildAllowlistScript({ domains: [] });
    expect(script).toContain('isAllowed');
    expect(script).toContain('__RNBridgeAllowlist__');
  });

  test('输出包含 matchDomain 源码', () => {
    const script = buildAllowlistScript({ domains: [] });
    expect(script).toContain('matchDomain');
    expect(script).toContain('endsWith');
  });

  test('allowLocalhost=false 时注入 false', () => {
    const script = buildAllowlistScript({ domains: [], allowLocalhost: false });
    expect(script).toContain('ALLOW_LOCALHOST  = false');
  });

  test('allowLocalhost=true（默认）时注入 true', () => {
    const script = buildAllowlistScript({ domains: [] });
    expect(script).toContain('ALLOW_LOCALHOST  = true');
  });

  test('注入脚本中 $ 字符（域名含特殊字符）不破坏替换', () => {
    // 验证 replace() 使用函数形式，$ 不被误解析
    const script = buildAllowlistScript({ domains: ['$example.com'] });
    expect(script).toContain('"$example.com"');
  });
});
