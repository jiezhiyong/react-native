/**
 * __tests__/bridge-sdk.test.ts
 *
 * 覆盖：
 * - BridgeError：构造、is()、from()
 * - isDomainAllowed：白名单全局变量联动
 * - call()：Bridge 未就绪时返回 rejected Promise
 * - call()：正常调用透传参数
 * - call()：reject 自动包装为 SDK BridgeError（instanceof 正确）
 * - onBridgeReady：已就绪时同步执行、未就绪时监听事件、超时告警
 * - onRNEvent：订阅 / 取消订阅
 * - registerBeforeBack / registerNavHandler：未就绪时抛 BridgeError
 */

import {
  BridgeError,
  BridgeErrorCode,
  isDomainAllowed,
  onBridgeReady,
  onRNEvent,
  registerBeforeBack,
  registerNavHandler,
  call as _call, // 内部函数，通过 Bridge.auth.tryLogin 等间接测试
} from '../../bridge-sdk-v6';

// ── jsdom 环境辅助 ────────────────────────────────────────────

function clearBridge() {
  delete (window as any).__RNBridge__;
  delete (window as any).__RNBridgeAllowlist__;
}

function installBridge(overrides?: Partial<typeof window.__RNBridge__>) {
  const mockCall = jest.fn().mockResolvedValue({ ok: true });
  const mockRegister = jest.fn();
  (window as any).__RNBridge__ = {
    version:  '1.0',
    call:     mockCall,
    register: mockRegister,
    ...overrides,
  };
  return { mockCall, mockRegister };
}

beforeEach(() => {
  clearBridge();
  jest.useFakeTimers();
});

afterEach(() => {
  jest.useRealTimers();
  clearBridge();
});

// ── BridgeError ───────────────────────────────────────────────

describe('BridgeError（SDK 端）', () => {
  test('构造：code 和 name 正确', () => {
    const err = new BridgeError(BridgeErrorCode.USER_CANCELED);
    expect(err.code).toBe(BridgeErrorCode.USER_CANCELED);
    expect(err.name).toBe('BridgeError');
  });

  test('instanceof BridgeError 为 true', () => {
    const err = new BridgeError(BridgeErrorCode.TIMEOUT);
    expect(err instanceof BridgeError).toBe(true);
  });

  test('instanceof Error 为 true', () => {
    const err = new BridgeError(BridgeErrorCode.TIMEOUT);
    expect(err instanceof Error).toBe(true);
  });
});

describe('BridgeError.is()', () => {
  test('SDK BridgeError 返回 true', () => {
    const err = new BridgeError(BridgeErrorCode.CAMERA_DENIED);
    expect(BridgeError.is(err)).toBe(true);
  });

  test('注入脚本风格的 BridgeError-like 对象返回 true', () => {
    const errLike = { name: 'BridgeError', code: '30002', message: '相机权限被拒绝' };
    expect(BridgeError.is(errLike)).toBe(true);
  });

  test('普通 Error 返回 false', () => {
    expect(BridgeError.is(new Error('plain'))).toBe(false);
  });

  test('null / undefined 返回 false', () => {
    expect(BridgeError.is(null)).toBe(false);
    expect(BridgeError.is(undefined)).toBe(false);
  });

  test('缺少 message 字段的对象返回 false', () => {
    // is() 要求 name + code + message 三个字段
    const incomplete = { name: 'BridgeError', code: '10000' };
    expect(BridgeError.is(incomplete)).toBe(false);
  });
});

describe('BridgeError.from()', () => {
  test('SDK BridgeError 直接包装为新实例', () => {
    const original = new BridgeError(BridgeErrorCode.USER_CANCELED, '用户取消');
    const result = BridgeError.from(original);
    expect(result).not.toBeNull();
    expect(result instanceof BridgeError).toBe(true);
    expect(result!.code).toBe(BridgeErrorCode.USER_CANCELED);
    expect(result!.message).toBe('用户取消');
  });

  test('注入脚本风格对象包装为 SDK BridgeError 实例', () => {
    const errLike = { name: 'BridgeError', code: '20001', message: '用户已取消' };
    const result = BridgeError.from(errLike);
    expect(result instanceof BridgeError).toBe(true);
    expect(result!.code).toBe('20001');
  });

  test('非 BridgeError 对象返回 null', () => {
    expect(BridgeError.from(new Error('plain'))).toBeNull();
    expect(BridgeError.from(null)).toBeNull();
    expect(BridgeError.from('string')).toBeNull();
  });
});

// ── isDomainAllowed ───────────────────────────────────────────

describe('isDomainAllowed()', () => {
  test('未安装白名单时返回 true（全部放行）', () => {
    delete (window as any).__RNBridgeAllowlist__;
    expect(isDomainAllowed()).toBe(true);
  });

  test('白名单安装后，当前域名命中时返回 true', () => {
    (window as any).__RNBridgeAllowlist__ = {
      isAllowed: (host: string) => host === 'localhost',
    };
    // jsdom 默认 location.hostname = 'localhost'
    expect(isDomainAllowed()).toBe(true);
  });

  test('当前域名不在白名单时返回 false', () => {
    (window as any).__RNBridgeAllowlist__ = {
      isAllowed: (_: string) => false,
    };
    expect(isDomainAllowed()).toBe(false);
  });
});

// ── call() guard（通过 bridge-sdk 模块导出的各 Bridge.xxx 方法间接测试）

describe('call() — Bridge 未就绪', () => {
  test('Bridge 未安装时返回 rejected Promise（不抛同步错误）', async () => {
    clearBridge();
    // 通过直接 import 调用 call 需要访问内部，这里通过导入模块并调用公开 API
    const { Bridge } = await import('../../bridge-sdk-v6');
    await expect(Bridge.auth.tryLogin()).rejects.toMatchObject({
      code: BridgeErrorCode.BRIDGE_DESTROYED,
    });
  });

  test('rejected 可以被 await catch 捕获（不是同步 TypeError）', async () => {
    clearBridge();
    const { Bridge } = await import('../../bridge-sdk-v6');
    let caught: unknown = null;
    try {
      await Bridge.auth.logout();
    } catch (e) {
      caught = e;
    }
    expect(caught instanceof BridgeError).toBe(true);
  });
});

describe('call() — rejection 包装', () => {
  test('注入脚本风格错误被包装为 SDK BridgeError（instanceof 正确）', async () => {
    const nativeErr = { name: 'BridgeError', code: '30002', message: '相机权限拒绝' };
    installBridge({
      call: jest.fn().mockRejectedValue(nativeErr),
    });
    const { Bridge } = await import('../../bridge-sdk-v6');
    let caught: unknown = null;
    try {
      await Bridge.photo.pickImage();
    } catch (e) {
      caught = e;
    }
    expect(caught instanceof BridgeError).toBe(true);
    expect((caught as BridgeError).code).toBe('30002');
  });

  test('非 BridgeError 的原生异常原样抛出', async () => {
    installBridge({
      call: jest.fn().mockRejectedValue(new TypeError('network error')),
    });
    const { Bridge } = await import('../../bridge-sdk-v6');
    await expect(Bridge.location.getLocation()).rejects.toBeInstanceOf(TypeError);
  });
});

// ── onBridgeReady ─────────────────────────────────────────────

describe('onBridgeReady()', () => {
  test('Bridge 已就绪时同步执行 callback', () => {
    installBridge();
    const cb = jest.fn();
    onBridgeReady(cb);
    expect(cb).toHaveBeenCalledTimes(1);
  });

  test('Bridge 未就绪时监听 RNBridgeReady 事件', () => {
    clearBridge();
    const cb = jest.fn();
    onBridgeReady(cb);
    expect(cb).not.toHaveBeenCalled();

    // 模拟注入脚本触发事件
    installBridge();
    window.dispatchEvent(new Event('RNBridgeReady'));
    expect(cb).toHaveBeenCalledTimes(1);
  });

  test('RNBridgeReady 事件只触发一次（{ once: true }）', () => {
    clearBridge();
    const cb = jest.fn();
    onBridgeReady(cb);
    window.dispatchEvent(new Event('RNBridgeReady'));
    window.dispatchEvent(new Event('RNBridgeReady')); // 第二次
    expect(cb).toHaveBeenCalledTimes(1);
  });

  test('超时后打印 console.warn', () => {
    clearBridge();
    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});
    onBridgeReady(jest.fn(), 3000);
    jest.advanceTimersByTime(3001);
    expect(warnSpy).toHaveBeenCalledWith(expect.stringContaining('onBridgeReady timeout'));
    warnSpy.mockRestore();
  });

  test('就绪后清除超时计时器（不触发 warn）', () => {
    clearBridge();
    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});
    onBridgeReady(jest.fn(), 3000);
    // 就绪事件在超时前触发
    installBridge();
    window.dispatchEvent(new Event('RNBridgeReady'));
    jest.advanceTimersByTime(5000); // 超过超时时间
    expect(warnSpy).not.toHaveBeenCalled();
    warnSpy.mockRestore();
  });
});

// ── onRNEvent ─────────────────────────────────────────────────

describe('onRNEvent()', () => {
  test('监听并接收 RNEvent 自定义事件', () => {
    const handler = jest.fn();
    onRNEvent('testEvt', handler);
    window.dispatchEvent(
      new CustomEvent('RNEvent:testEvt', { detail: { value: 42 } }),
    );
    expect(handler).toHaveBeenCalledWith({ value: 42 });
  });

  test('返回的清理函数能移除监听', () => {
    const handler = jest.fn();
    const cleanup = onRNEvent('cleanEvt', handler);
    cleanup();
    window.dispatchEvent(new CustomEvent('RNEvent:cleanEvt', { detail: {} }));
    expect(handler).not.toHaveBeenCalled();
  });

  test('不同事件名互不干扰', () => {
    const h1 = jest.fn();
    const h2 = jest.fn();
    onRNEvent('evt1', h1);
    onRNEvent('evt2', h2);
    window.dispatchEvent(new CustomEvent('RNEvent:evt1', { detail: 'for-1' }));
    expect(h1).toHaveBeenCalledWith('for-1');
    expect(h2).not.toHaveBeenCalled();
  });
});

// ── registerBeforeBack / registerNavHandler ───────────────────

describe('registerBeforeBack()', () => {
  test('Bridge 未就绪时抛 BridgeError(BRIDGE_DESTROYED)', () => {
    clearBridge();
    expect(() => registerBeforeBack(async () => true))
      .toThrow(expect.objectContaining({ code: BridgeErrorCode.BRIDGE_DESTROYED }));
  });

  test('Bridge 已就绪时调用 register', () => {
    const { mockRegister } = installBridge();
    const handler = async () => true;
    registerBeforeBack(handler);
    expect(mockRegister).toHaveBeenCalledWith('onBeforeBack', handler);
  });
});

describe('registerNavHandler()', () => {
  test('Bridge 未就绪时抛 BridgeError(BRIDGE_DESTROYED)', () => {
    clearBridge();
    expect(() => registerNavHandler('handleSave', async () => {}))
      .toThrow(expect.objectContaining({ code: BridgeErrorCode.BRIDGE_DESTROYED }));
  });

  test('Bridge 已就绪时注册指定方法名', () => {
    const { mockRegister } = installBridge();
    const fn = async () => {};
    registerNavHandler('handleSave', fn);
    expect(mockRegister).toHaveBeenCalledWith('handleSave', fn);
  });
});
