/**
 * __tests__/setup.ts — 全局测试环境配置
 *
 * 在每个测试文件执行前运行，提供：
 * - React Native 核心模块 Mock
 * - Expo Router Mock
 * - 常用全局变量（__DEV__）
 */

// ── 全局变量 ──────────────────────────────────────────────────

(global as any).__DEV__ = true;

// ── React Native 核心 Mock ────────────────────────────────────

jest.mock('react-native', () => ({
  Platform: {
    OS:      'ios',
    Version: '17.0',
    select:  (obj: Record<string, unknown>) => obj.ios ?? obj.default,
  },
  Dimensions: {
    get: (_: string) => ({ width: 390, height: 844 }),
  },
  PixelRatio: {
    get: () => 3,
  },
  Linking: {
    openURL:    jest.fn().mockResolvedValue(undefined),
    canOpenURL: jest.fn().mockResolvedValue(true),
  },
  AppState: {
    currentState: 'active',
    addEventListener: jest.fn(() => ({ remove: jest.fn() })),
  },
  BackHandler: {
    addEventListener: jest.fn(() => ({ remove: jest.fn() })),
  },
  StyleSheet: {
    create: (s: unknown) => s,
  },
}));

// ── Expo Router Mock ──────────────────────────────────────────

jest.mock('expo-router', () => ({
  router: {
    push:       jest.fn(),
    replace:    jest.fn(),
    back:       jest.fn(),
    navigate:   jest.fn(),
    dismiss:    jest.fn(),
    dismissAll: jest.fn(),
  },
  useRouter:             () => ({ push: jest.fn(), back: jest.fn(), replace: jest.fn() }),
  useLocalSearchParams:  () => ({}),
  useNavigation:         () => ({
    setOptions:    jest.fn(),
    addListener:   jest.fn(() => jest.fn()),
    dispatch:      jest.fn(),
  }),
}));

// ── 全局 console 静默（避免测试输出噪音）────────────────────

const originalWarn  = console.warn;
const originalError = console.error;

beforeAll(() => {
  // 只静默 React Native 和 Expo 的已知警告
  console.warn = (...args: unknown[]) => {
    const msg = args[0]?.toString() ?? '';
    if (
      msg.includes('Animated:') ||
      msg.includes('NativeEventEmitter') ||
      msg.includes('VirtualizedList')
    ) return;
    originalWarn(...args);
  };
  console.error = (...args: unknown[]) => {
    const msg = args[0]?.toString() ?? '';
    if (msg.includes('Warning:')) return; // React 内部警告
    originalError(...args);
  };
});

afterAll(() => {
  console.warn  = originalWarn;
  console.error = originalError;
});
