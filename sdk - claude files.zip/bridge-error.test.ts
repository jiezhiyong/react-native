/**
 * __tests__/lib/bridge-error.test.ts
 *
 * 覆盖：
 * - BridgeError 构造、name、code、message、instanceof
 * - toBridgeError 各路径
 * - BridgeErrorMessages 完整性（每个错误码都有描述）
 * - BridgeErrorCode 值格式（5 位数字字符串）
 */

import {
  BridgeError,
  BridgeErrorCode,
  BridgeErrorMessages,
  toBridgeError,
} from '../../lib/bridge-error';

describe('BridgeErrorCode', () => {
  test('所有错误码均为 5 位数字字符串', () => {
    Object.values(BridgeErrorCode).forEach(code => {
      expect(typeof code).toBe('string');
      expect(code).toMatch(/^\d{5}$/);
    });
  });

  test('错误码按范围分层', () => {
    expect(BridgeErrorCode.UNKNOWN).toMatch(/^1/);
    expect(BridgeErrorCode.USER_CANCELED).toMatch(/^2/);
    expect(BridgeErrorCode.CAMERA_DENIED).toMatch(/^3/);
    expect(BridgeErrorCode.NOT_LOGGED_IN).toMatch(/^4/);
    expect(BridgeErrorCode.LOCATION_TIMEOUT).toMatch(/^5/);
  });

  test('不存在重复值', () => {
    const values = Object.values(BridgeErrorCode);
    const unique = new Set(values);
    expect(unique.size).toBe(values.length);
  });
});

describe('BridgeErrorMessages', () => {
  test('每个错误码都有对应的中文描述', () => {
    Object.values(BridgeErrorCode).forEach(code => {
      expect(BridgeErrorMessages[code]).toBeTruthy();
      expect(typeof BridgeErrorMessages[code]).toBe('string');
    });
  });
});

describe('BridgeError', () => {
  test('构造：code 和默认 message', () => {
    const err = new BridgeError(BridgeErrorCode.USER_CANCELED);
    expect(err.code).toBe(BridgeErrorCode.USER_CANCELED);
    expect(err.message).toBe(BridgeErrorMessages[BridgeErrorCode.USER_CANCELED]);
    expect(err.name).toBe('BridgeError');
  });

  test('构造：自定义 message', () => {
    const err = new BridgeError(BridgeErrorCode.TIMEOUT, '自定义超时信息');
    expect(err.message).toBe('自定义超时信息');
  });

  test('instanceof 检查正确', () => {
    const err = new BridgeError(BridgeErrorCode.UNKNOWN);
    expect(err instanceof BridgeError).toBe(true);
    expect(err instanceof Error).toBe(true);
  });

  test('子类 instanceof 正常工作（ES5 编译兼容）', () => {
    class SubError extends BridgeError {}
    const err = new SubError(BridgeErrorCode.UNKNOWN);
    expect(err instanceof BridgeError).toBe(true);
    expect(err instanceof Error).toBe(true);
  });

  test('不同实例之间 instanceof 独立', () => {
    const err = new BridgeError(BridgeErrorCode.CAMERA_DENIED);
    const plain = new Error('plain');
    expect(plain instanceof BridgeError).toBe(false);
    expect(err instanceof BridgeError).toBe(true);
  });
});

describe('toBridgeError', () => {
  test('BridgeError 直接透传', () => {
    const original = new BridgeError(BridgeErrorCode.LOCATION_DENIED);
    const result = toBridgeError(original);
    expect(result).toBe(original); // 同一引用
    expect(result.code).toBe(BridgeErrorCode.LOCATION_DENIED);
  });

  test('普通 Error → UNKNOWN，非 debug 模式不暴露 message', () => {
    const err = new Error('内部错误详情');
    const result = toBridgeError(err, false);
    expect(result instanceof BridgeError).toBe(true);
    expect(result.code).toBe(BridgeErrorCode.UNKNOWN);
    expect(result.message).not.toContain('内部错误详情');
  });

  test('普通 Error → UNKNOWN，debug 模式保留 message', () => {
    const err = new Error('内部错误详情');
    const result = toBridgeError(err, true);
    expect(result.code).toBe(BridgeErrorCode.UNKNOWN);
    expect(result.message).toBe('内部错误详情');
  });

  test('非 Error 值（字符串）→ UNKNOWN', () => {
    const result = toBridgeError('something went wrong');
    expect(result.code).toBe(BridgeErrorCode.UNKNOWN);
  });

  test('null → UNKNOWN', () => {
    const result = toBridgeError(null);
    expect(result.code).toBe(BridgeErrorCode.UNKNOWN);
  });
});
