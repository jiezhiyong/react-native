# RN WebView Bridge

一套为 **React Native（Expo + Expo Router）** 应用设计的 WebView JS Bridge 方案，提供 Native App 与内嵌 H5 页面之间完整的双向通信能力。

---

## 特性

- **双向通信**：H5 调用 Native 能力（Promise 风格），RN 向 H5 推送事件
- **统一错误码**：结构化 `BridgeError`，5 位数字码分层，H5 端 `instanceof` 可靠
- **域名白名单**：两层防御（H5 侧注入脚本 + RN 侧消息拦截），防止未授权调用
- **多实例安全**：所有状态与 `BridgeInstanceState` 绑定，多个 WebView 同时存在互不干扰
- **StrictMode 安全**：注册表读写分离，`useEffect` 执行两次不会导致页面关闭
- **事件队列**：H5 就绪前的 `pushEvent` 暂存，就绪后自动冲刷，不丢失

---

## 项目结构

```
lib/
  bridge-config.ts          白名单域名配置（按环境修改此文件）
  bridge-core-v6.ts         通信核心（消息收发、Promise、白名单、事件队列）
  bridge-allowlist.ts       域名白名单匹配逻辑
  bridge-error.ts           统一错误码枚举与 BridgeError 类
  bridge-instance-registry  多 WebView 实例状态注册表
  native-handlers-v6.ts     所有 Handler 统一注册入口
  webview-registry.ts       WebView URL 注册表

handlers/
  auth.ts                   登录授权（tryLogin / forceLogin / logout）
  location.ts               定位（精度控制、超时竞争）
  photo.ts                  图片（选图/拍照/预览/保存相册）
  share.ts                  分享（微信分享 / 系统分享面板）
  storage.ts                本地存储（AsyncStorage 封装，命名空间隔离）
  utils.ts                  系统工具（扫码/PDF/拨号/系统信息/重力感应/剪贴板/通讯录）
  webview-nav.ts            页面管理（navigateTo/redirectTo/reLaunch 等）

app/webview/index.tsx       WebView 页面组件
bridge-sdk-v6.ts            H5 端 SDK（TypeScript 类型安全封装）
```

---

## 安装依赖

```bash
# 核心
expo install react-native-webview
expo install @react-native-async-storage/async-storage
expo install @react-native-clipboard/clipboard

# 原生能力
expo install expo-location
expo install expo-image-picker
expo install expo-media-library
expo install expo-file-system
expo install expo-sharing
expo install expo-barcode-scanner
expo install expo-contacts
expo install expo-sensors
expo install expo-network
expo install expo-device
expo install expo-application
expo install expo-intent-launcher
expo install expo-notifications
```

---

## 快速上手

### 1. 配置白名单

编辑 `lib/bridge-config.ts`，添加允许调用 Bridge 的 H5 域名：

```typescript
export const BRIDGE_ALLOWLIST: AllowlistOptions = {
  domains: [
    'your-domain.com',
    '*.your-domain.com',
  ],
  allowLocalhost: __DEV__,
  allowHttp: false,
};
```

### 2. 打开 WebView 页面

```typescript
import { useOpenWebView } from '@/hooks/useOpenWebView';

function MyScreen() {
  const openWebView = useOpenWebView();

  return (
    <Button
      title="打开 H5"
      onPress={() => openWebView('https://your-domain.com/page', '页面标题')}
    />
  );
}
```

### 3. H5 端引入 SDK

将 `bridge-sdk-v6.ts` 复制到 H5 项目，然后：

```typescript
import Bridge, { onBridgeReady, BridgeError, BridgeErrorCode } from './bridge-sdk-v6';

onBridgeReady(async () => {
  // 获取用户信息
  const { user } = await Bridge.auth.forceLogin();
  console.log('用户:', user.nickname);

  // 获取位置
  const pos = await Bridge.location.getLocation({ accuracy: 'high' });
  console.log(`${pos.latitude}, ${pos.longitude}`);

  // 选择图片
  const { assets } = await Bridge.photo.pickImage({ source: 'camera' });
  console.log('图片:', assets[0].uri);
});
```

### 4. 错误处理

```typescript
try {
  await Bridge.photo.pickImage({ source: 'camera' });
} catch (e) {
  if (!(e instanceof BridgeError)) throw e;

  switch (e.code) {
    case BridgeErrorCode.USER_CANCELED:
      break; // 用户取消，静默处理
    case BridgeErrorCode.CAMERA_DENIED:
      await Bridge.utils.openSettings(); // 引导开启权限
      break;
    case BridgeErrorCode.DOMAIN_NOT_ALLOWED:
      console.error('当前域名未授权'); // 配置问题
      break;
    default:
      showToast(e.message);
  }
}
```

---

## API 参考

### auth — 登录授权

| 方法 | 说明 | 返回 |
|------|------|------|
| `auth.tryLogin()` | 静默检查登录态，不弹界面 | `{ isLoggedIn, user? }` |
| `auth.forceLogin(options?)` | 强制登录，未登录则弹登录页等待 | `{ isLoggedIn: true, user }` |
| `auth.logout()` | 退出登录 | `{ ok: true }` |

### location — 定位

| 方法 | 说明 |
|------|------|
| `location.getLocation(options?)` | 获取当前位置，支持精度级别和超时控制 |
| `location.checkPermission()` | 检查定位权限状态（不申请） |

**精度级别**：`lowest / low / balanced / high / highest / bestForNavigation`

### photo — 图片

| 方法 | 说明 |
|------|------|
| `photo.pickImage(options?)` | 从相册选图或拍照，支持多选 |
| `photo.previewImage(urls, current?)` | 全屏预览图片 |
| `photo.closePreview()` | 关闭预览 |
| `photo.saveImageToAlbum(url)` | 保存图片到系统相册（支持远程 URL） |

### share — 分享

| 方法 | 说明 |
|------|------|
| `share.wechatWebpage(options)` | 微信分享网页 |
| `share.wechatImage(options)` | 微信分享图片 |
| `share.wechatMiniProgram(options)` | 微信分享小程序 |
| `share.shareDocument(options)` | 系统分享面板（PDF、链接等） |

> 微信分享需要接入微信 SDK，参见 `handlers/share.ts` 中的接入点注释。

### storage — 本地存储

所有操作均为异步，key 自动加 `bridge:` 命名空间前缀。

| 方法 | 说明 |
|------|------|
| `storage.setItem(key, value)` | 存储任意 JSON 可序列化值（限 1MB） |
| `storage.getItem<T>(key)` | 读取，不存在返回 `{ value: null }` |
| `storage.removeItem(key)` | 删除单项 |
| `storage.clear()` | 清除 bridge 命名空间下所有数据 |
| `storage.multiGet(keys)` | 批量读取 |
| `storage.multiSet(items)` | 批量写入 |
| `storage.multiRemove(keys)` | 批量删除 |

### utils — 系统工具

| 方法 | 说明 |
|------|------|
| `utils.scanCode()` | 扫码（二维码/条形码），打开扫码页 |
| `utils.previewPDF(url, title?)` | 预览 PDF |
| `utils.makeCall(phoneNumber)` | 拨号 |
| `utils.getSystemInfo()` | 获取设备/系统/网络信息 |
| `utils.startGravity(options?)` | 开始重力感应，数据通过 `onRNEvent('gravity')` 接收 |
| `utils.stopGravity(subscriptionId)` | 停止重力感应 |
| `utils.getClipboard()` | 读取剪贴板 |
| `utils.setClipboard(text)` | 写入剪贴板 |
| `utils.getContacts(options?)` | 读取通讯录（分页 + 搜索） |
| `utils.checkPermission(type)` | 检查权限状态（不申请） |
| `utils.openSettings()` | 打开系统设置 |
| `utils.sendSMS(phoneNumber, body?)` | 打开短信应用 |

### webview — 页面管理

| 方法 | 说明 |
|------|------|
| `webview.navigateTo(url, title?)` | 打开新 WebView（push） |
| `webview.redirectTo(url, title?)` | 替换当前页（replace） |
| `webview.locationTo(url)` | WebView 内跳转，SPA 框架可拦截 |
| `webview.reLaunch(url, title?)` | 关闭所有页面，重新打开 |
| `webview.navigateBack(delta?)` | 回退 |
| `webview.switchTab(tabName)` | 切换底部 Tab |

### navbar — 导航栏

```typescript
// 设置标题和右侧按钮，注册点击处理器
await Bridge.navbar.setNavBar({
  title: '编辑资料',
  rightButton: { type: 'text', label: '保存', onPressHandler: 'handleSave' },
  interceptBack: true,
});

registerNavHandler('handleSave', async () => {
  await submitForm();
});

registerBeforeBack(async () => {
  if (!isDirty) return true;
  return await showConfirmDialog('放弃修改？');
});
```

### 生命周期事件

```typescript
import { onRNEvent } from './bridge-sdk-v6';

onRNEvent('onShow', () => console.log('App 回到前台'));
onRNEvent('onHide', () => console.log('App 进入后台'));
onRNEvent('onPageShow', ({ url }) => console.log('页面加载完成:', url));

// 重力感应数据
const cleanup = onRNEvent('gravity', ({ x, y, z }) => {
  console.log('加速度:', x, y, z);
});
// 停止时调用 cleanup()
```

---

## 错误码

| 范围 | 说明 | 典型错误码 |
|------|------|-----------|
| `10xxx` | Bridge 系统层 | `10001` 方法未注册，`10003` 超时，`10005` 域名未授权 |
| `20xxx` | 用户行为 | `20001` 用户取消，`20002` 用户拒绝 |
| `30xxx` | 系统权限 | `30002` 相机，`30003` 定位，`30004` 相册 |
| `40xxx` | 业务逻辑 | `40001` 未登录，`40002` 登录失败 |
| `50xxx` | 原生能力 | `50001` 定位超时，`50003` 分享不可用 |

完整列表见 `lib/bridge-error.ts`。

---

## 登录页集成

登录页通过路由参数 `bridgeId` 拿到 Bridge 实例，完成登录回调：

```typescript
// app/login.tsx
import { useLocalSearchParams } from 'expo-router';
import { getBridgeInstance } from '@/lib/bridge-instance-registry';
import { resolveLogin, rejectLogin } from '@/handlers/auth';

export default function LoginPage() {
  const { bridgeId } = useLocalSearchParams<{ bridgeId: string }>();

  const handleLoginSuccess = (user: UserInfo) => {
    const state = getBridgeInstance(bridgeId);
    if (state) resolveLogin(state, user);
    router.back();
  };

  const handleCancel = () => {
    const state = getBridgeInstance(bridgeId);
    if (state) rejectLogin(state); // 触发 USER_CANCELED
    router.back();
  };
  // ...
}
```

## 扫码页集成

```typescript
// app/scanner.tsx
import { useLocalSearchParams } from 'expo-router';
import { getBridgeInstance } from '@/lib/bridge-instance-registry';
import { resolveScan, rejectScan } from '@/handlers/utils';

export default function ScannerPage() {
  const { bridgeId } = useLocalSearchParams<{ bridgeId: string }>();

  const handleScanResult = (result: string, type: string) => {
    const state = getBridgeInstance(bridgeId);
    if (state) resolveScan(state, result, type);
    router.back();
  };

  const handleCancel = () => {
    const state = getBridgeInstance(bridgeId);
    if (state) rejectScan(state, true); // true = 用户取消
    router.back();
  };
  // ...
}
```

---

## 兼容性

| 平台 | 最低版本 | 说明 |
|------|---------|------|
| iOS | 15.0+ | Expo SDK 50+ 要求 |
| Android | 6.0+ (API 23) | Expo SDK 50+ 要求 |
| WebView | iOS 9 / Android 4.4+ | 注入脚本使用 ES6 Map / Promise |

---

## 开发注意事项

1. **白名单配置**：修改 `lib/bridge-config.ts`，不要在组件内硬编码域名
2. **多 WebView 实例**：所有状态通过 `BridgeInstanceState` 隔离，勿使用模块级变量
3. **Bridge 就绪时机**：H5 业务逻辑必须在 `onBridgeReady(callback)` 内执行
4. **微信分享接入**：需替换 `handlers/share.ts` 中 `wechatShare()` 函数体
5. **扫码/PDF 页面**：需自行实现 `app/scanner.tsx` 和 `app/pdf-viewer.tsx`
