/**
 * __mocks__/store.ts — Zustand store Mock
 *
 * 替代真实的 @/lib/store，供 handler 测试使用。
 * 各测试文件可通过 mockGetState.mockReturnValue({...}) 覆盖返回值。
 */

export const mockSetUser = jest.fn();
export const mockGetState = jest.fn().mockReturnValue({
  user:    null,
  setUser: mockSetUser,
});

export const useAppStore = Object.assign(
  jest.fn(),
  {
    getState: mockGetState,
    setState: jest.fn(),
    subscribe: jest.fn(() => jest.fn()),
  },
);
