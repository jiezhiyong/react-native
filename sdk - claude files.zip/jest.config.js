// jest.config.js
/** @type {import('jest').Config} */
module.exports = {
  preset: 'jest-expo',

  // 测试文件匹配
  testMatch: [
    '**/__tests__/**/*.test.ts',
    '**/__tests__/**/*.test.tsx',
  ],

  // 模块别名（对应 tsconfig paths）
  moduleNameMapper: {
    '^@/lib/(.*)$':      '<rootDir>/lib/$1',
    '^@/handlers/(.*)$': '<rootDir>/handlers/$1',
    '^@/hooks/(.*)$':    '<rootDir>/hooks/$1',
    '^@/lib/store$':     '<rootDir>/__mocks__/store.ts',
  },

  // 转换配置
  transform: {
    '^.+\\.(js|jsx|ts|tsx)$': [
      'babel-jest',
      { presets: ['babel-preset-expo'] },
    ],
  },

  // 需要转换的 node_modules（Expo 包使用 ESM）
  transformIgnorePatterns: [
    'node_modules/(?!(' + [
      '@react-native',
      'react-native',
      'expo',
      'expo-location',
      'expo-image-picker',
      'expo-media-library',
      'expo-file-system',
      'expo-sharing',
      'expo-barcode-scanner',
      'expo-contacts',
      'expo-sensors',
      'expo-network',
      'expo-device',
      'expo-application',
      'expo-intent-launcher',
      'expo-notifications',
      '@react-native-async-storage',
      '@react-native-clipboard',
    ].join('|') + ')/)',
  ],

  // 测试环境（bridge-sdk 需要 jsdom，native 代码需要 node）
  testEnvironment: 'jsdom',

  // 覆盖率收集
  collectCoverageFrom: [
    'lib/**/*.ts',
    'handlers/**/*.ts',
    'bridge-sdk-v6.ts',
    '!lib/bridge-types.ts', // 纯类型文件
    '!**/*.d.ts',
  ],

  // 覆盖率阈值
  coverageThreshold: {
    global: {
      branches:   70,
      functions:  80,
      lines:      80,
      statements: 80,
    },
  },

  // 全局 setup
  setupFilesAfterFramework: ['<rootDir>/__tests__/setup.ts'],

  // 超时（默认 5s，扫码/登录测试可能需要更长）
  testTimeout: 10000,
};
