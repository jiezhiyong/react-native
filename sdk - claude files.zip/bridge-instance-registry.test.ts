/**
 * __tests__/lib/bridge-instance-registry.test.ts
 *
 * 覆盖：
 * - registerBridgeInstance / getBridgeInstance / unregisterBridgeInstance
 * - 存储的是对象引用（可变）
 * - 卸载后返回 null
 * - 多实例互不干扰
 */

import {
  registerBridgeInstance,
  unregisterBridgeInstance,
  getBridgeInstance,
} from '../../lib/bridge-instance-registry';
import { createInstanceState, BridgeInstanceState } from '../../lib/bridge-core-v6';

function makeState(bridgeId = 'test-id'): BridgeInstanceState {
  const state = createInstanceState();
  state.bridgeId = bridgeId;
  return state;
}

describe('bridge-instance-registry', () => {
  afterEach(() => {
    // 清理所有测试注册的实例
    ['id-a', 'id-b', 'id-c', 'test-id'].forEach(unregisterBridgeInstance);
  });

  test('注册后可以取回同一个 state 引用', () => {
    const state = makeState('id-a');
    registerBridgeInstance('id-a', state);
    const retrieved = getBridgeInstance('id-a');
    expect(retrieved).toBe(state); // 严格引用相等
  });

  test('取回的 state 是可变引用（修改后 get 仍看到新值）', () => {
    const state = makeState('id-a');
    registerBridgeInstance('id-a', state);
    // 模拟登录页修改 loginResolver
    const mockResolver = jest.fn();
    state.loginResolver = mockResolver;
    const retrieved = getBridgeInstance('id-a');
    expect(retrieved?.loginResolver).toBe(mockResolver);
  });

  test('unregisterBridgeInstance 后返回 null', () => {
    const state = makeState('id-a');
    registerBridgeInstance('id-a', state);
    unregisterBridgeInstance('id-a');
    expect(getBridgeInstance('id-a')).toBeNull();
  });

  test('未注册的 id 返回 null', () => {
    expect(getBridgeInstance('non-existent')).toBeNull();
  });

  test('unregisterBridgeInstance 幂等', () => {
    const state = makeState('id-a');
    registerBridgeInstance('id-a', state);
    unregisterBridgeInstance('id-a');
    expect(() => unregisterBridgeInstance('id-a')).not.toThrow();
    expect(getBridgeInstance('id-a')).toBeNull();
  });

  test('多实例并存互不干扰', () => {
    const stateA = makeState('id-a');
    const stateB = makeState('id-b');
    registerBridgeInstance('id-a', stateA);
    registerBridgeInstance('id-b', stateB);

    expect(getBridgeInstance('id-a')).toBe(stateA);
    expect(getBridgeInstance('id-b')).toBe(stateB);

    unregisterBridgeInstance('id-a');
    expect(getBridgeInstance('id-a')).toBeNull();
    expect(getBridgeInstance('id-b')).toBe(stateB); // B 不受影响
  });

  test('重复注册同一 id 会覆盖', () => {
    const stateOld = makeState('id-a');
    const stateNew = makeState('id-a');
    registerBridgeInstance('id-a', stateOld);
    registerBridgeInstance('id-a', stateNew);
    expect(getBridgeInstance('id-a')).toBe(stateNew);
  });
});
