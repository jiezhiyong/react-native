/**
 * __tests__/lib/webview-registry.test.ts
 *
 * 覆盖：
 * - registerWebViewUrl：生成唯一 ID、存储 url 和 title
 * - resolveWebViewUrl：只读不删除（StrictMode 安全）
 * - deleteWebViewUrl：显式删除后返回 null
 * - 多条目并存互不干扰
 */

import {
  registerWebViewUrl,
  resolveWebViewUrl,
  deleteWebViewUrl,
} from '../../lib/webview-registry';

describe('webview-registry', () => {
  test('注册后可以解析到 url 和 title', () => {
    const id = registerWebViewUrl('https://example.com', '示例页面');
    const entry = resolveWebViewUrl(id);
    expect(entry).not.toBeNull();
    expect(entry?.url).toBe('https://example.com');
    expect(entry?.title).toBe('示例页面');
  });

  test('title 可以省略', () => {
    const id = registerWebViewUrl('https://example.com/no-title');
    const entry = resolveWebViewUrl(id);
    expect(entry?.title).toBeUndefined();
  });

  test('resolveWebViewUrl 只读不删除（StrictMode 安全）', () => {
    const id = registerWebViewUrl('https://example.com/strict');
    // 连续读取两次均返回同一条目
    expect(resolveWebViewUrl(id)).not.toBeNull();
    expect(resolveWebViewUrl(id)).not.toBeNull();
  });

  test('deleteWebViewUrl 删除后返回 null', () => {
    const id = registerWebViewUrl('https://example.com/delete-me');
    expect(resolveWebViewUrl(id)).not.toBeNull();
    deleteWebViewUrl(id);
    expect(resolveWebViewUrl(id)).toBeNull();
  });

  test('deleteWebViewUrl 幂等（重复删除不报错）', () => {
    const id = registerWebViewUrl('https://example.com/idempotent');
    deleteWebViewUrl(id);
    expect(() => deleteWebViewUrl(id)).not.toThrow();
    expect(resolveWebViewUrl(id)).toBeNull();
  });

  test('多条目并存互不干扰', () => {
    const id1 = registerWebViewUrl('https://a.com', 'A');
    const id2 = registerWebViewUrl('https://b.com', 'B');
    expect(id1).not.toBe(id2);
    expect(resolveWebViewUrl(id1)?.url).toBe('https://a.com');
    expect(resolveWebViewUrl(id2)?.url).toBe('https://b.com');
    deleteWebViewUrl(id1);
    expect(resolveWebViewUrl(id1)).toBeNull();
    expect(resolveWebViewUrl(id2)?.url).toBe('https://b.com'); // B 不受影响
    deleteWebViewUrl(id2);
  });

  test('未注册的 id 返回 null', () => {
    expect(resolveWebViewUrl('non-existent-id')).toBeNull();
  });

  test('每次注册返回唯一 id', () => {
    const ids = Array.from({ length: 10 }, () =>
      registerWebViewUrl('https://example.com'),
    );
    const unique = new Set(ids);
    expect(unique.size).toBe(10);
    ids.forEach(deleteWebViewUrl);
  });
});
